const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  next();
});

app.use((req, res, next) => {
console.log('demande du client en JSON : ', req.body);
var Gpio = require('onoff').Gpio; //importation de la librairie onoff et on inter réagit avec le port GPIO      
if(req.body.canal){ //condition obligatoire, sinon la broche n'est pas définit erreur !
var LED = new Gpio(req.body.canal, 'out'); //On instancie un objet qui va utiliser la broche du processeur qui se nomme GPIO4

  changeRL(req.body.etat);
  function changeRL(position) {
    LED.writeSync(position); //set pin state to 1 (turn LED on)
  }
}
  next();
});

app.use((req, res, next) => {
  res.status(201);
  next();
});

app.use((req, res, next) => {
  res.json({ message: 'Votre requête a bien été reçue !' });
  next();
});

app.use((req, res, next) => {
  console.log('canal et postion ok');
});

module.exports = app;
