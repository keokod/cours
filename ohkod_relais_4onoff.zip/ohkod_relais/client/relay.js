var RL = false;

const isChecked=document.querySelectorAll('.lever');

isChecked.forEach(el => el.addEventListener('click',event =>{    
    var canal = event.target.getAttribute("data-GPIO");
    changeRL(canal,RL)
    RL = !RL;
}))

function changeRL(canal,RL){
    RL ? reqOnOff(canal,1) : reqOnOff(canal,0); //attention le relais travail = gpio à 0
}

function reqOnOff(canal,position){
    var url = "http://192.168.1.15:8000";
    let xhr = new XMLHttpRequest();

    let json = JSON.stringify({
      "canal": canal,
      "etat": position
    });
    
    xhr.open("POST", url)
    xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');
    xhr.send(json);
}